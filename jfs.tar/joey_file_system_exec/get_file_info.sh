FLAG_LOC="/home/joey_file_system/flag.txt"
cat $FLAG_LOC